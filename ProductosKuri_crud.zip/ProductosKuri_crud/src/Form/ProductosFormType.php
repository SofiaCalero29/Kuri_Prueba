<?php

namespace App\Form;

use App\Entity\Producto;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ProductosFormType extends AbstractType
{
    private const INPUT_STYLE="form-control";
    private const LABEL_STYLE="form-label mt-3 fw-bold text-dark";
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('clave_producto', TextType::class, [
                'label'=>'Clave del producto: ',
                'required'=>true,
                'label_attr'=>[
                    'class'=>self::LABEL_STYLE,
                ],
                'attr'=>[
                    'class'=>self::INPUT_STYLE,
                    'id'=>'producto_form_clave_producto',
                    'placeholder'=>'Clave'
                ]
            ])
            ->add('nombre', TextType::class, [
                'label'=>'Nombre: ',
                'required'=>true,
                'label_attr'=>[
                    'class'=>self::LABEL_STYLE,
                ],
                'attr'=>[
                    'class'=>self::INPUT_STYLE,
                    'id'=>'producto_form_nombre',
                    'placeholder'=>'Nombre'
                ]
            ])
            ->add('precio', TextType::class, [
                'label'=>'Precio: ',
                'required'=>true,
                'label_attr'=>[
                    'class'=>self::LABEL_STYLE,
                ],
                'attr'=>[
                    'class'=>self::INPUT_STYLE,
                    'id'=>'producto_form_precio',
                    'placeholder'=>'Precio'
                ]
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Producto::class,
        ]);
    }
}
