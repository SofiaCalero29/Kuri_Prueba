<?php

namespace App\Controller;

use App\Entity\Producto;
use App\Form\ProductosFormType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class HomeController extends AbstractController
{
    private $em;
    public function __construct(EntityManagerInterface $em)
    {
        $this->em=$em;
    }

    #[Route('/', name: 'crud')]
    public function index(): Response
    {
        $productos=$this->em->getRepository(Producto::class)->findAll();
        return $this->render('home/index.html.twig',[
            'productos'=>$productos,
        ]);
    }

    #[Route('/crud/add', name: 'crud_add')]
    public function add(Request $request): Response
    {
        $producto=new Producto();
        $form = $this->createForm(ProductosFormType::class, $producto);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            try{
                $campos=$form->getData();
                $producto->setClaveProducto($campos->getClaveProducto());
                $producto->setNombre($campos->getNombre());
                $producto->setPrecio($campos->getPrecio());
                $this->em->persist($producto);
                $this->em->flush();
                return $this->redirectToRoute("crud");
            }catch(\Exception $e){
                return $this->redirectToRoute("crud_add");
            }
        }else{
            return $this->render('home/add.html.twig', [
                'form'=>$form->createView(),
            ]);
        }
    }
    #[Route('/crud/update/{id}', name: 'crud_update')]
    public function update(int $id, Request $request): Response
    {
        $producto=$this->em->getRepository(Producto::class)->find($id);
        if(!$producto){
            throw $this->createNotFoundException('No se encontro el registro con el id= '.$id);
        }
        $form=$this->createForm(ProductosFormType::class, $producto);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            try{
                $this->em->flush();
                return $this->redirectToRoute('crud',['id'=>$id]);
            }catch(\Exception $e){
                return $this->redirectToRoute('crud_update',['id'=>$id]);
            }
        }else{
            return $this->render('home/update.html.twig',[
                'form'=>$form->createView(),
                'producto'=>$producto,
            ]);
        }
    }

    #[Route('/crud/delete/{id}', name: 'crud_delete')]
    public function delete(int $id): Response
    {
        $producto=$this->em->getRepository(Producto::class)->find($id);
        if(!$producto){
            throw $this->createNotFoundException('No se encontro el registro con el id= '.$id);
        }
        $this->em->remove($producto);
        $this->em->flush();
        return $this->redirectToRoute('crud');
    }

}
